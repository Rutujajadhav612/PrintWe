import React from 'react'

function infoSection() {
  return (
    <div>infoSection</div>
  )
}

export default infoSection