import React from 'react'
import RegisterForm from '../components/RegisterForm'

function Register() {
  return (
    <div className="flex-grow">
      <RegisterForm />
    </div>
  )
}

export default Register