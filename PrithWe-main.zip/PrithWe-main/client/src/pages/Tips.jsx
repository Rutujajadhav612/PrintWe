import React from 'react'
import TipsSection from '../components/TipsSection'

function Tips() {
  return (
    <div className="flex-grow">
      <TipsSection />
    </div>
  )
}

export default Tips