import React from 'react';
import ContactUsForm from '../components/ContactUsForm';

function ContactUs() {
  return (
    <div className='flex-grow'>
        <ContactUsForm />
    </div>
  )
}

export default ContactUs;